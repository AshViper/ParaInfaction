Minimal TIS-3d compat class

- Tis3dClipContext
    - provides a modified ClipContext that only hits blocks that are solid but
      not transparent
