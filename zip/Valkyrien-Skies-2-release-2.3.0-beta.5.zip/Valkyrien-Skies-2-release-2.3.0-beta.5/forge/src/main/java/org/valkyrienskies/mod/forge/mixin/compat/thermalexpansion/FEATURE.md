### Thermal Expansion Compatibility

This feature adds compatibility fixes to make Thermal Expansion work properly on
ships.

#### Mixins

* `MixinTileCoFH#prePlayerWithinDistance` Fixes Thermal Expansion GUIs closing
  immediately after the Player opens them
