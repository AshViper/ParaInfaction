package org.valkyrienskies.mod.util

object KrunchSupport {
    var isKrunchSupported = false
}
