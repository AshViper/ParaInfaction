package org.valkyrienskies.mod.common.entity.handling

object DefaultShipyardEntityHandler : AbstractShipyardEntityHandler()
