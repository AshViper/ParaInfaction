package org.valkyrienskies.mod.mixinducks.com.mojang.blaze3d.audio;

import org.joml.Vector3dc;

public interface HasOpenALVelocity {
    void setVelocity(final Vector3dc velocity);
}
