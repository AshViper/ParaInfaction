package org.valkyrienskies.mod.mixinducks.mod_compat.create;

public interface IMixinStickerTileEntity {

    boolean isAlreadyPowered(boolean reset);
}
