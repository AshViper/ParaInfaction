package org.valkyrienskies.mod.mixinducks.world.entity;

import org.valkyrienskies.mod.common.util.MinecraftPlayer;

public interface PlayerDuck {

    MinecraftPlayer vs_getPlayer();

}
