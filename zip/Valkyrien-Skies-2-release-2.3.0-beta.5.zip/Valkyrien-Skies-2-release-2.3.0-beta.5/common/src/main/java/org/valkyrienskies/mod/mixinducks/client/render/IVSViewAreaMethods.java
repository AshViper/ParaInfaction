package org.valkyrienskies.mod.mixinducks.client.render;

public interface IVSViewAreaMethods {
    void unloadChunk(int chunkX, int chunkZ);
}
