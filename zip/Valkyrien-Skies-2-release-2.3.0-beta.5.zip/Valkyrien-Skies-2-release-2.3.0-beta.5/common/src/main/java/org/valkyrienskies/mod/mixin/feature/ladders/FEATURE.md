### Ladders

This feature makes ladders work on ships

#### Mixins

* `MixinLivingEntity#onClimbableMixin` Calls onClimbable for every ship that is
  near in shipyard.
