These mixins make jukeboxes play correctly on ships and gives
them doppler shift.
