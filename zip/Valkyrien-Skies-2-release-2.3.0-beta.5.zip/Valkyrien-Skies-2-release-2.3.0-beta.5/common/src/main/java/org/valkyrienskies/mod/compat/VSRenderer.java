package org.valkyrienskies.mod.compat;

public enum VSRenderer {
    VANILLA, OPTIFINE, SODIUM
}
