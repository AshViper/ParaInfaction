package org.valkyrienskies.mod.mixinducks.feature.seamless_copy;

import org.valkyrienskies.mod.common.assembly.SeamlessChunksManager;

public interface SeamlessCopyClientPacketListenerDuck {
    SeamlessChunksManager vs_getChunks();
}
