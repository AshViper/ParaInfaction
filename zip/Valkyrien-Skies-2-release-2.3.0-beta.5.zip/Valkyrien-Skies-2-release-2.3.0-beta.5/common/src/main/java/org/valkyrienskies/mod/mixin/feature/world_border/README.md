These mixins ensure that ships keep working even if the player has reduced their
world border.
