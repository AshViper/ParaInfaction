# Block Tinting

These mixins fix block tinting for blocks on ships.

(Only updates if the chunk render buffer is updated)

Adds a client side option in the config (called "fixBlockTinting" in the category "BlockTinting") to enable this feature.
(default off!)
