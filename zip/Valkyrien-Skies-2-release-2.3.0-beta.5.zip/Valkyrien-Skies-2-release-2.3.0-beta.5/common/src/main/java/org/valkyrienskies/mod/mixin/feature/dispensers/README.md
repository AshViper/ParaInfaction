These mixins ensure that dispensers dispense items with the correct
velocity/position when on ships
