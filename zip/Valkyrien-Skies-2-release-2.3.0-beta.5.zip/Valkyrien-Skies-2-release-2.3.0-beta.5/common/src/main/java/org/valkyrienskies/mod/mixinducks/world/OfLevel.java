package org.valkyrienskies.mod.mixinducks.world;

import net.minecraft.world.level.Level;

public interface OfLevel {

    Level getLevel();

    void setLevel(Level level);

}
