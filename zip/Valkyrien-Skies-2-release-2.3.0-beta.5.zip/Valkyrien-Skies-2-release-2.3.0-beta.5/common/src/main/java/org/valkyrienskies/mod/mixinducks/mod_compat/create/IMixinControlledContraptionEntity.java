package org.valkyrienskies.mod.mixinducks.mod_compat.create;

import com.simibubi.create.content.contraptions.IControlContraption;

public interface IMixinControlledContraptionEntity {
    IControlContraption grabController();
}
