package net.optifine.render;

/**
 * Dummy class that exists so we can generate certain Mixins. This class is removed from the jar after compilation by
 * gradle.
 */
public class VboRegion {
    public void deleteGlBuffers() {
        throw new IllegalStateException();
    }
}
